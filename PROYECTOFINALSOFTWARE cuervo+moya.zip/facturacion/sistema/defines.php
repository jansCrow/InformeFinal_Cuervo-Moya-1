<?php
	define('HOST', 'localhost');
	define('DB', 'facturacion');
	define('USER', 'root');
	define('PASS', '');
?>